=============================
BCBlib: neuroimaging analyses
=============================

Under development

Repository of scripts and tools used for MRI data analysis